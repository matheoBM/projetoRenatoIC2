#include<stdio.h>
#include<stdlib.h>

#define tamanhoMax 10

typedef struct  
{
    char string[10];
}string;

//para contar o numero de linhas
int contador();


void main ()
{
    FILE *arq;
    
    /*int linhasMes1 = contador("mes_1.txt");
    int linhasMes2 = contador("mes_2.txt");
    int linhasMes3 = contador("mes_3.txt");
    int linhasMes4 = contador("mes_4.txt");
    int linhasMes5 = contador("mes_5.txt");

    printf("%d\n%d\n%d\n", linhasMes1,linhasMes2,linhasMes3);

    string codigo1[linhasMes1];
    string codigo2[linhasMes2];
    string codigo3[linhasMes3];
    string codigo4[linhasMes4];
    string codigo5[linhasMes5];
    */
    /*for(int i = 0; i < linhasMes1; i++)
    {
        fgets(codigo1[i].string, tamanhoMax+1 , arq);
    }

    for(int i = 0; i < 10; i++)
    {
        printf("%s", codigo1[i].string);
    }*/
    for(int i = 1; i <= 1; i++)
    {
        //essa tres linhas são para converter int em string
        
        char nomeArq[10];
        sprintf(nomeArq , "mes_%d.txt", i); 
        printf("%s\n", nomeArq);

        int linhasMes1 = contador(nomeArq);
        arq = fopen(nomeArq, "r");
        string codigo1[linhasMes1];

        for(int i = 0; i < linhasMes1; i++)
        {
            fgets(codigo1[i].string, tamanhoMax+1 , arq);
        }
        for(int i = 0; i < 4; i++)
        {
            printf("%s", codigo1[i].string);
        }
        //coloca o alg de ordenaçaõ aqui




        fclose(arq);
    }



}

int contador(char *nome)
{                                   
    FILE *arq = fopen(nome,"r");
    int linhas = 0;
    char ch;
    while(!feof(arq))
    {
        ch = fgetc(arq);
        if(ch == '\n')
        {   
            linhas++;
        }
    }
    return linhas;
}