#include<stdio.h>
#include<stdlib.h>
#include<string.h>
#define tamanhoMax 10

typedef struct  
{
    char string[11];
}string;

//para contar o numero de linhas
int contador();

void selecao();

int contador_movimentacao = 0;
int contadorComp = 0;

void main ()
{
    FILE *arq;

    for(int i = 1; i <= 5; i++)
    {
        //essa tres linhas são para converter int em string
        char nomeArq[10];
        sprintf(nomeArq , "mes_%d.txt", i); 
        printf("%s\n", nomeArq);
        
        int linhas = contador(nomeArq);
        arq = fopen(nomeArq, "r");
        string codigo[linhas + 1];

        for(int i = 1; i <= linhas; i++)
        {
            fgets(codigo[i].string, tamanhoMax+1 , arq);
            fgets(codigo[i+1].string, tamanhoMax+1, arq);
        }
        
        //coloca o alg de ordenação aqui
        selecao(codigo, linhas);

        fclose(arq);
        arq = fopen(nomeArq, "w");
        
        for( int i = 1; i <= linhas; i++)
        {
            fprintf(arq,"%s\n", codigo[i].string); 
        }
        fclose(arq);
        
    }



}

int contador(char *nome)
{                                   
    FILE *arq = fopen(nome,"r");
    int linhas = 0;
    char ch;
    while(!feof(arq))
    {
        ch = fgetc(arq);
        if(ch == '\n')
        {   
            linhas++;
        }
    }
    return linhas;
}

void selecao(string lista[], int numero)
{
    string x;
    int indice_menor;

    for(int i = 1; i < numero; i++)
    {
        indice_menor = i;
        for( int j = i + 1; j <= numero; j++)
        {
            contadorComp++;
            if(strcmp(lista[j].string, lista[indice_menor].string) < 0)
            {
                indice_menor = j;
            }
        }
        x = lista[i];
        lista[i] = lista[indice_menor];
        lista[indice_menor] = x;
        contador_movimentacao = contador_movimentacao + 3;
    }
    
}
