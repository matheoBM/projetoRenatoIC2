#include<stdio.h>
#include<stdlib.h>
#include<string.h>
#define tamanhoMax 10

typedef struct  
{
    char string[11];
}string;

//para contar o numero de linhas
int contador();
void insercao();

void main ()
{
    FILE *arq;

    for(int i = 1; i <= 5; i++)
    {
        //essa tres linhas são para converter int em string
        char nomeArq[10];
        sprintf(nomeArq , "mes_%d.txt", i); 
        printf("%s\n", nomeArq);
        
        int linhas = contador(nomeArq);
        arq = fopen(nomeArq, "r");
        string codigo[linhas + 1];

        for(int i = 1; i <= linhas; i++)
        {
            fgets(codigo[i].string, tamanhoMax+1 , arq);
            fgets(codigo[i+1].string, tamanhoMax+1, arq);
        }
        
        //coloca o alg de ordenação aqui
        insercao(codigo, linhas);

        fclose(arq);
        arq = fopen(nomeArq, "w");

        for( int i = 1; i <= linhas; i++)
        {
            fprintf(arq,"%s\n", codigo[i].string); 
        }
        fclose(arq);
        
    }



}

int contador(char *nome)
{                                   
    FILE *arq = fopen(nome,"r");
    int linhas = 0;
    char ch;
    while(!feof(arq))
    {
        ch = fgetc(arq);
        if(ch == '\n')
        {   
            linhas++;
        }
    }
    return linhas;
}

void insercao(string lista[], int numero)
{
    string x;
    int j;
    for (int i = 2; i < numero; i++)
    {
        x =  lista[i];
        lista[0] =  x;
        j = i;
        while( strcmp(x.string, lista[j-1].string) < 0)
        {
            lista[j] = lista[j-1];
            j = j - 1;
        }
        lista[j]= x;
    
    }
}